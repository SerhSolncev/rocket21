document.addEventListener('DOMContentLoaded', (event) => {

  const getElement = (context, selector) => {
    if (!context && !selector) {
      return null;
    }

    return context.querySelector(selector);
  };

  document.body.classList.add('loading');

  setTimeout(() => {
    document.body.classList.add('loaded');
  }, 500)

  // "modernizr" func"
  function isTouchDevice() {
    return 'ontouchstart' in window || navigator.maxTouchPoints;
  }

  // lazy-load
  const el = document.querySelectorAll('.lazy');
  window.observer = lozad(el);
  window.observer.observe();


  // swiper users
  let swiperUsers = null;

  function initSwiperUsers() {
    const screenWidth = window.innerWidth;
    if (screenWidth >= 768 && swiperUsers) {
      swiperUsers.destroy(true, true);
      swiperUsers = null;
    } else if (screenWidth < 768 && !swiperUsers) {
      swiperUsers = new Swiper('.js-users-swiper', {
        slidesPerView: 1,
        spaceBetween: 10,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        navigation: {
          nextEl: '.js-user-next',
          prevEl: '.js-user-prev',
        }
      });
    }
  }

  window.addEventListener('load', initSwiperUsers);
  window.addEventListener('resize', initSwiperUsers);

  // tabs
  document.addEventListener('click', (event) => {
    const tabsParent = event.target.closest('.js-tabs-wrapper');

    if (tabsParent) {
      const buttonTab = tabsParent.querySelectorAll('.js-tabs-button');
      const blockTab = tabsParent.querySelectorAll('.js-tabs-block');
      const clickedButton = event.target.closest('.js-tabs-button');

      if (clickedButton) {
        const id = clickedButton.getAttribute('data-id');

        buttonTab.forEach((button) => {
          button.classList.remove('opened');
        });

        blockTab.forEach((block) => {
          block.classList.remove('opened');
        });

        clickedButton.classList.add('opened');
        tabsParent.querySelectorAll('.js-tabs-button[data-id="' + id + '"]').forEach((all) => {
          all.classList.add('opened');
        })
        tabsParent.querySelector('.js-tabs-block[data-id="' + id + '"]').classList.add('opened');
      }
    }
  });


  // chart js

  const ctx = document.getElementById('myChart').getContext('2d');
  const chartCanvas = document.querySelector('.chart-canvas');
  const chartBtns = document.querySelectorAll('.js-chart-btn');
  const labels = JSON.parse(chartCanvas.getAttribute('data-labels'));
  let data = JSON.parse(chartCanvas.getAttribute('data-data'));

  const yGridGradient = ctx.createLinearGradient(0, 0, 0, ctx.canvas.height);
  yGridGradient.addColorStop(0, 'rgba(255, 181, 193, 0.1)');
  yGridGradient.addColorStop(1, 'rgba(253, 251, 251, 0.1)');

  const xGridGradient = ctx.createLinearGradient(0, 0, ctx.canvas.width, 0);
  xGridGradient.addColorStop(0, 'rgba(255, 181, 193, 0.1)');
  xGridGradient.addColorStop(1, 'rgba(253, 251, 251, 0.1)');

  const dataConfig = {
    labels: labels,
    datasets: [{
      label: 'Points',
      data: data,
      borderWidth: 1,
      borderColor: 'rgba(255, 99, 132, 1)',
      backgroundColor: 'rgba(255, 99, 132, 0.2)',
      fill: true,
      tension: 0.1,
      pointRadius: 0,
      pointHoverRadius: 0
    }],
  };

  const optionsConfig = {
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: yGridGradient
        },
        ticks: {
          color: '#9A9494'
        }
      },
      x: {
        grid: {
          color: xGridGradient,
        },
        border: {
          dash: [8],
        },
        ticks: {
          color: '#9A9494'
        },
        // offset: 1 // Добавляем отступы по бокам
      }
    },
    plugins: {
      legend: {
        display: false // Скрываем легенду
      }
    }
  };


  let myChart = new Chart(ctx, {
    type: 'line',
    data: dataConfig,
    options: optionsConfig
  });


  chartBtns.forEach((btn) => {
    btn.addEventListener('click', (event) => {
      myChart.data.datasets[0].data = JSON.parse(btn.getAttribute('data-data'));
      myChart.update();

      let target = document.querySelector('.chart-wrap__right');
      let targetPosition = target.getBoundingClientRect().top + window.scrollY - 30;

      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    });

    btn.addEventListener('mouseover', () => {
      const dataId = btn.getAttribute('data-id');
      document.querySelectorAll(`[data-id="${dataId}"]`).forEach(el => {
        el.classList.add('data-item-hover');
      });
    });

    btn.addEventListener('mouseout', () => {
      const dataId = btn.getAttribute('data-id');
      document.querySelectorAll(`[data-id="${dataId}"]`).forEach(el => {
        el.classList.remove('data-item-hover');
      });
    });
  })
})
